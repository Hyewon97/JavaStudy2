
 class Access1 {
	
	private String userid = "goguma";
	String userpwd = "kangsan";
	 Access1() {
		System.out.println("아이디 = " + userid);
	}
	 //반환형 메소드명()
	 void printData() {
		 System.out.println("id = " + userid);
		 System.out.println("pwd = " + userpwd);
	 }

}
