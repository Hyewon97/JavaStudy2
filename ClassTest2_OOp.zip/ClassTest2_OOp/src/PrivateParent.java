
public class PrivateParent {
	
	private int num = 100;
	int age = 30;
	public PrivateParent() {
		
	}
	private void setNum() {
		num += 100;
	}
	public  int getNum() {
		return num;
	}
}
